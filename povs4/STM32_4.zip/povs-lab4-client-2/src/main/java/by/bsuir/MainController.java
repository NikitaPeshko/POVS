package by.bsuir;

import javafx.animation.Animation;
import javafx.animation.Transition;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.util.Duration;
import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;

import java.util.PriorityQueue;
import java.util.Queue;

public class MainController {

    @FXML
    private TextField comPortTextField;

    @FXML
    private Button buildButton;

    @FXML
    private LineChart<String, Number> lightChart;

    @FXML
    private LineChart<String, Number> temperatureChart;

    public static SerialPort serialPort;

    public static Animation animation;

    private int seconds;

    private final Queue<Integer> lightQueue = new PriorityQueue<>(10);
    private final Queue<Double> temperatureQueue = new PriorityQueue<>(10);

    @FXML
    void initialize() {
        XYChart.Series<String, Number> temperatureSeries = new XYChart.Series<>();
        temperatureSeries.setName("Температура");
        temperatureChart.getData().add(temperatureSeries);

        XYChart.Series<String, Number> lightSeries = new XYChart.Series<>();
        lightSeries.setName("Освещенность");
        lightChart.getData().add(lightSeries);

        buildButton.setOnAction(handler -> processButton());

        animation = new Transition() {
            {
                setCycleDuration(Duration.seconds(2));
                setCycleCount(INDEFINITE);
            }
            @Override
            protected void interpolate(double frac) {
                if (temperatureQueue.size() != 0 && lightQueue.size() != 0) {
                    XYChart.Data<String, Number> temperatureData = new XYChart.Data<>(String.valueOf(seconds), temperatureQueue.poll());
                    temperatureChart.getData().get(0).getData().add(temperatureData);

                    XYChart.Data<String, Number> lightData = new XYChart.Data<>(String.valueOf(seconds), lightQueue.poll());
                    lightChart.getData().get(0).getData().add(lightData);

                    seconds += 2;
                }
            }
        };
        animation.play();
    }

    private void processButton() {
        String value = comPortTextField.getText();
        if (value.matches("COM[1-9]")) {
            serialPort = new SerialPort(value);
            try {
                serialPort.openPort();
                buildButton.setDisable(true);
                comPortTextField.setDisable(true);

                serialPort.setParams(
                        SerialPort.BAUDRATE_115200,
                        SerialPort.DATABITS_8,
                        SerialPort.STOPBITS_1,
                        SerialPort.PARITY_NONE
                );
                serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN);
                serialPort.addEventListener(new PortReader(), SerialPort.MASK_RXCHAR);
            } catch (SerialPortException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Ошибка");
                alert.setHeaderText(null);
                alert.setContentText("Порт " + value + " недоступен");
                alert.show();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setHeaderText(null);
            alert.setContentText("Значение должно быть COM1-COM9");
            alert.show();
        }
    }

    private class PortReader implements SerialPortEventListener {

        public PortReader() {
            try {
                if (serialPort.getInputBufferBytesCount() != 0) {
                    serialPort.readString(serialPort.getInputBufferBytesCount());
                }
            } catch (SerialPortException e) {
                e.printStackTrace();
            }
        }

        public void serialEvent(SerialPortEvent event) {
            try {
                if (event.isRXCHAR() && event.getEventValue() == 11) {
                    String data = serialPort.readString(event.getEventValue());

                    String[] values = data.split("\\s+");
                    Double temperature = Double.parseDouble(values[0]);
                    Integer light = Integer.parseInt(values[1]);

                    temperatureQueue.add(temperature);
                    lightQueue.add(light);
                }
            } catch (SerialPortException ex) {
                ex.printStackTrace();
            }
        }
    }

}
